
package com.tencent.sample;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.sample.GetPkBragParamsDialog.OnGetPkBragParamsCompleteListener;
import com.tencent.tauth.Constants;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Vector;

public class GetAskGiftParamsDialog extends Dialog implements
        android.view.View.OnClickListener {

    public interface OnGetAskGiftParamsCompleteListener {
        public void onGetParamsComplete(Bundle params);
    }

    private OnGetAskGiftParamsCompleteListener mListener = null;

    private Context mContext = null;

    // private HashMap<String, Object> mHmParams = null;
    private Bundle mParams = null;

    private Vector<String> mOpenids = new Vector<String>();

    private Button mBtCommit = null;

    private Spinner mSpOptions = null;
    private TextView mTvReceiver = null;
    private TextView mTvTitle = null;
    private TextView mTvMsg = null;
    private TextView mTvImg = null;
    private TextView mTvExclude = null;
    private TextView mTvSpecified = null;
    private Spinner mSpOnly = null;
    private TextView mTvSource = null;

    public GetAskGiftParamsDialog(Context context, OnGetAskGiftParamsCompleteListener listener) {
        super(context, R.style.Dialog_Fullscreen);
        // TODO Auto-generated constructor stub
        mContext = context;
        mListener = listener;
        // mHmParams = new HashMap<String, Object>();
        mParams = new Bundle();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.get_ask_gift_params_dialog);
        findViews();
        setupViews();
    }

    private void findViews() {
        mSpOptions = (Spinner) findViewById(R.id.sp_options);
        mTvReceiver = (TextView) findViewById(R.id.et_receiver);
        mTvTitle = (TextView) findViewById(R.id.et_title);
        mTvMsg = (TextView) findViewById(R.id.et_msg);
        mTvImg = (TextView) findViewById(R.id.et_img);
        mTvExclude = (TextView) findViewById(R.id.et_exclude);
        mTvSpecified = (TextView) findViewById(R.id.et_specified);
        mSpOnly = (Spinner) findViewById(R.id.sp_only);
        mTvSource = (TextView) findViewById(R.id.et_source);
        mBtCommit = (Button) findViewById(R.id.bt_commit);

    }

    private void setupViews() {
        mBtCommit.setOnClickListener(this);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                android.R.layout.simple_spinner_item);
        adapter.add(mContext.getResources().getString(R.string.choice1));
        adapter.add(mContext.getResources().getString(R.string.choice2));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpOptions.setAdapter(adapter);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(mContext,
                android.R.layout.simple_spinner_item);
        adapter2.add(mContext.getResources().getString(R.string.ask_gift_only1));
        adapter2.add(mContext.getResources().getString(R.string.ask_gift_only2));
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpOnly.setAdapter(adapter2);

        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    @Override
    public void onClick(View arg0) {
        if (arg0 == mBtCommit) {
            getInputParams();
            mListener.onGetParamsComplete(mParams);
            this.dismiss();
            // if (mHmParams.size() > 0) {
            // mListener.onGetParamsComplete(mHmParams);
            // this.dismiss();
            // } else {
            // mListener.onGetParamsComplete(null);
            // this.dismiss();
            // }
        } else {
            Toast.makeText(mContext, "Openid must not be empty",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void getInputParams() {
        // type
        if (mSpOptions.getSelectedItem() != null) {
            mParams.putString(Constants.PARAM_TYPE, (String) mSpOptions.getSelectedItem());
        }

        // receiver
        if (mTvReceiver.getText().toString() != null && mTvReceiver.getText().toString().length() != 0) {
            mParams.putString(Constants.PARAM_RECEIVER, mTvReceiver.getText().toString());
        } else {
            mParams.putString(Constants.PARAM_RECEIVER, "");
        }

        // title
        if (mTvTitle.getText().toString() != null && mTvTitle.getText().toString().length() != 0) {
            mParams.putString(Constants.PARAM_TITLE, mTvTitle.getText().toString());
        } else {
            mParams.putString(Constants.PARAM_TITLE, "title字段测试");
        }

        // msg
        if (mTvMsg.getText().toString() != null && mTvMsg.getText().toString().length() > 0) {
            mParams.putString(Constants.PARAM_SEND_MSG, mTvMsg.getText().toString());
        } else {
            mParams.putString(Constants.PARAM_SEND_MSG, "msg字段测试");
        }

        // img
        if (mTvImg.getText().toString() != null && mTvImg.getText().toString().length() != 0) {
            mParams.putString(Constants.PARAM_IMG_URL, mTvImg.getText().toString());
        } else {
            mParams.putString(Constants.PARAM_IMG_URL,
                    "http://i.gtimg.cn/qzonestyle/act/qzone_app_img/app888_888_75.png");
        }

        // exclude
        if (mTvExclude.getText().toString() != null && mTvExclude.getText().toString().length() != 0) {
            mParams.putString("exclude", mTvExclude.getText().toString());
        } else {
            mParams.putString("exclude", "");
        }

        // specified
        if (mTvSpecified.getText().toString() != null && mTvSpecified.getText().toString().length() != 0) {
            mParams.putString("specified", mTvSpecified.getText().toString());
        } else {
            mParams.putString("specified", "");
        }

        // only
        if (mSpOnly.getSelectedItem() != null) {
            mParams.putString("only", (String) mSpOnly.getSelectedItem());
        }

        // source
        if (mTvSource.getText().toString() != null && mTvSource.getText().toString().length() != 0) {
            mParams.putString(Constants.PARAM_SOURCE,
                    URLEncoder.encode(mTvSource.getText().toString()));
        } else {
            mParams.putString(Constants.PARAM_SOURCE,
                    URLEncoder.encode(""));
        }

    }

}
